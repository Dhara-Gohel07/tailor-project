﻿namespace dashboard
{
    partial class customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.close_btn = new System.Windows.Forms.Button();
            this.maxi_btn = new System.Windows.Forms.Button();
            this.mini_btn = new System.Windows.Forms.Button();
            this.header_panel = new System.Windows.Forms.Panel();
            this.home_btn = new System.Windows.Forms.Button();
            this.measur_btn = new System.Windows.Forms.Button();
            this.cust_btn = new System.Windows.Forms.Button();
            this.bill_btn = new System.Windows.Forms.Button();
            this.menu = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menu_pic = new System.Windows.Forms.PictureBox();
            this.menu_panel = new System.Windows.Forms.Panel();
            this.cuspage_panel = new System.Windows.Forms.Panel();
            this.cusdelete_btn = new System.Windows.Forms.Button();
            this.cusupdate_btn = new System.Windows.Forms.Button();
            this.cusadd_btn = new System.Windows.Forms.Button();
            this.cust_date = new System.Windows.Forms.DateTimePicker();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.mno_txt = new System.Windows.Forms.TextBox();
            this.cusnm_txt = new System.Windows.Forms.TextBox();
            this.age_txt = new System.Windows.Forms.TextBox();
            this.cusid_txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.header_panel.SuspendLayout();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).BeginInit();
            this.menu_panel.SuspendLayout();
            this.cuspage_panel.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // close_btn
            // 
            this.close_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close_btn.FlatAppearance.BorderSize = 0;
            this.close_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.close_btn.Location = new System.Drawing.Point(1565, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 67);
            this.close_btn.TabIndex = 1;
            this.close_btn.Text = "X";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // maxi_btn
            // 
            this.maxi_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maxi_btn.FlatAppearance.BorderSize = 0;
            this.maxi_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxi_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxi_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.maxi_btn.Location = new System.Drawing.Point(1493, 0);
            this.maxi_btn.Name = "maxi_btn";
            this.maxi_btn.Size = new System.Drawing.Size(75, 67);
            this.maxi_btn.TabIndex = 2;
            this.maxi_btn.Text = "[ ]";
            this.maxi_btn.UseVisualStyleBackColor = true;
            this.maxi_btn.Click += new System.EventHandler(this.maxi_btn_Click);
            // 
            // mini_btn
            // 
            this.mini_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mini_btn.FlatAppearance.BorderSize = 0;
            this.mini_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mini_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mini_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mini_btn.Location = new System.Drawing.Point(1421, 3);
            this.mini_btn.Name = "mini_btn";
            this.mini_btn.Size = new System.Drawing.Size(75, 66);
            this.mini_btn.TabIndex = 2;
            this.mini_btn.Text = "__";
            this.mini_btn.UseVisualStyleBackColor = true;
            this.mini_btn.Click += new System.EventHandler(this.mini_btn_Click);
            // 
            // header_panel
            // 
            this.header_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.header_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.header_panel.Controls.Add(this.mini_btn);
            this.header_panel.Controls.Add(this.maxi_btn);
            this.header_panel.Controls.Add(this.close_btn);
            this.header_panel.Location = new System.Drawing.Point(-14, -12);
            this.header_panel.Name = "header_panel";
            this.header_panel.Size = new System.Drawing.Size(1640, 67);
            this.header_panel.TabIndex = 0;
            // 
            // home_btn
            // 
            this.home_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.home_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.home_btn.FlatAppearance.BorderSize = 0;
            this.home_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.home_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.14286F);
            this.home_btn.ForeColor = System.Drawing.Color.White;
            this.home_btn.Image = global::dashboard.Properties.Resources.home1;
            this.home_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.home_btn.Location = new System.Drawing.Point(19, 233);
            this.home_btn.Name = "home_btn";
            this.home_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.home_btn.Size = new System.Drawing.Size(304, 91);
            this.home_btn.TabIndex = 0;
            this.home_btn.Text = "     HOME";
            this.home_btn.UseVisualStyleBackColor = false;
            this.home_btn.Click += new System.EventHandler(this.home_btn_Click);
            // 
            // measur_btn
            // 
            this.measur_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.measur_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.measur_btn.FlatAppearance.BorderSize = 0;
            this.measur_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.measur_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.measur_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 9.14286F);
            this.measur_btn.ForeColor = System.Drawing.Color.White;
            this.measur_btn.Image = global::dashboard.Properties.Resources.measurement1;
            this.measur_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.measur_btn.Location = new System.Drawing.Point(19, 496);
            this.measur_btn.Name = "measur_btn";
            this.measur_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.measur_btn.Size = new System.Drawing.Size(304, 91);
            this.measur_btn.TabIndex = 2;
            this.measur_btn.Text = "          MEASUREMENT";
            this.measur_btn.UseVisualStyleBackColor = false;
            this.measur_btn.Click += new System.EventHandler(this.measur_btn_Click);
            // 
            // cust_btn
            // 
            this.cust_btn.BackColor = System.Drawing.Color.Teal;
            this.cust_btn.Cursor = System.Windows.Forms.Cursors.Default;
            this.cust_btn.FlatAppearance.BorderSize = 0;
            this.cust_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cust_btn.Font = new System.Drawing.Font("Microsoft YaHei", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cust_btn.ForeColor = System.Drawing.Color.White;
            this.cust_btn.Image = global::dashboard.Properties.Resources.customer__1_;
            this.cust_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cust_btn.Location = new System.Drawing.Point(19, 364);
            this.cust_btn.Name = "cust_btn";
            this.cust_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.cust_btn.Size = new System.Drawing.Size(304, 91);
            this.cust_btn.TabIndex = 3;
            this.cust_btn.Text = "       CUSTOMERS";
            this.cust_btn.UseVisualStyleBackColor = false;
            // 
            // bill_btn
            // 
            this.bill_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.bill_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bill_btn.FlatAppearance.BorderSize = 0;
            this.bill_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bill_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bill_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_btn.ForeColor = System.Drawing.Color.White;
            this.bill_btn.Image = global::dashboard.Properties.Resources.bill1;
            this.bill_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bill_btn.Location = new System.Drawing.Point(19, 635);
            this.bill_btn.Name = "bill_btn";
            this.bill_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bill_btn.Size = new System.Drawing.Size(304, 91);
            this.bill_btn.TabIndex = 4;
            this.bill_btn.Text = "     BILL";
            this.bill_btn.UseVisualStyleBackColor = false;
            this.bill_btn.Click += new System.EventHandler(this.bill_btn_Click);
            // 
            // menu
            // 
            this.menu.Controls.Add(this.label1);
            this.menu.Controls.Add(this.menu_pic);
            this.menu.Cursor = System.Windows.Forms.Cursors.No;
            this.menu.Location = new System.Drawing.Point(19, 80);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(304, 69);
            this.menu.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(117, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "MENU";
            // 
            // menu_pic
            // 
            this.menu_pic.Image = global::dashboard.Properties.Resources.menu;
            this.menu_pic.Location = new System.Drawing.Point(0, 0);
            this.menu_pic.Name = "menu_pic";
            this.menu_pic.Size = new System.Drawing.Size(63, 66);
            this.menu_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menu_pic.TabIndex = 4;
            this.menu_pic.TabStop = false;
            // 
            // menu_panel
            // 
            this.menu_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menu_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.menu_panel.Controls.Add(this.menu);
            this.menu_panel.Controls.Add(this.bill_btn);
            this.menu_panel.Controls.Add(this.cust_btn);
            this.menu_panel.Controls.Add(this.measur_btn);
            this.menu_panel.Controls.Add(this.home_btn);
            this.menu_panel.Location = new System.Drawing.Point(-19, -19);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.Size = new System.Drawing.Size(323, 946);
            this.menu_panel.TabIndex = 1;
            // 
            // cuspage_panel
            // 
            this.cuspage_panel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cuspage_panel.BackColor = System.Drawing.Color.LightCyan;
            this.cuspage_panel.Controls.Add(this.cusdelete_btn);
            this.cuspage_panel.Controls.Add(this.cusupdate_btn);
            this.cuspage_panel.Controls.Add(this.cusadd_btn);
            this.cuspage_panel.Controls.Add(this.cust_date);
            this.cuspage_panel.Controls.Add(this.email_txt);
            this.cuspage_panel.Controls.Add(this.mno_txt);
            this.cuspage_panel.Controls.Add(this.cusnm_txt);
            this.cuspage_panel.Controls.Add(this.age_txt);
            this.cuspage_panel.Controls.Add(this.cusid_txt);
            this.cuspage_panel.Controls.Add(this.label8);
            this.cuspage_panel.Controls.Add(this.label7);
            this.cuspage_panel.Controls.Add(this.label6);
            this.cuspage_panel.Controls.Add(this.label5);
            this.cuspage_panel.Controls.Add(this.label4);
            this.cuspage_panel.Controls.Add(this.label2);
            this.cuspage_panel.Location = new System.Drawing.Point(303, 54);
            this.cuspage_panel.Name = "cuspage_panel";
            this.cuspage_panel.Size = new System.Drawing.Size(1320, 485);
            this.cuspage_panel.TabIndex = 6;
            // 
            // cusdelete_btn
            // 
            this.cusdelete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.cusdelete_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cusdelete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cusdelete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusdelete_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.cusdelete_btn.Location = new System.Drawing.Point(916, 366);
            this.cusdelete_btn.Name = "cusdelete_btn";
            this.cusdelete_btn.Size = new System.Drawing.Size(308, 58);
            this.cusdelete_btn.TabIndex = 50;
            this.cusdelete_btn.Text = "DELETE";
            this.cusdelete_btn.UseVisualStyleBackColor = false;
            // 
            // cusupdate_btn
            // 
            this.cusupdate_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.cusupdate_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cusupdate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cusupdate_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusupdate_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.cusupdate_btn.Location = new System.Drawing.Point(492, 366);
            this.cusupdate_btn.Name = "cusupdate_btn";
            this.cusupdate_btn.Size = new System.Drawing.Size(321, 58);
            this.cusupdate_btn.TabIndex = 49;
            this.cusupdate_btn.Text = "UPDATE";
            this.cusupdate_btn.UseVisualStyleBackColor = false;
            // 
            // cusadd_btn
            // 
            this.cusadd_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.cusadd_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cusadd_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cusadd_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusadd_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.cusadd_btn.Location = new System.Drawing.Point(61, 366);
            this.cusadd_btn.Name = "cusadd_btn";
            this.cusadd_btn.Size = new System.Drawing.Size(329, 58);
            this.cusadd_btn.TabIndex = 48;
            this.cusadd_btn.Text = "ADD";
            this.cusadd_btn.UseVisualStyleBackColor = false;
            // 
            // cust_date
            // 
            this.cust_date.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.cust_date.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.cust_date.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cust_date.Location = new System.Drawing.Point(834, 222);
            this.cust_date.MaxDate = new System.DateTime(2024, 7, 13, 0, 0, 0, 0);
            this.cust_date.Name = "cust_date";
            this.cust_date.Size = new System.Drawing.Size(423, 43);
            this.cust_date.TabIndex = 47;
            this.cust_date.Value = new System.DateTime(2024, 7, 13, 0, 0, 0, 0);
            // 
            // email_txt
            // 
            this.email_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.email_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_txt.Location = new System.Drawing.Point(834, 142);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(423, 32);
            this.email_txt.TabIndex = 20;
            // 
            // mno_txt
            // 
            this.mno_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.mno_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mno_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mno_txt.Location = new System.Drawing.Point(834, 71);
            this.mno_txt.Name = "mno_txt";
            this.mno_txt.Size = new System.Drawing.Size(423, 32);
            this.mno_txt.TabIndex = 19;
            // 
            // cusnm_txt
            // 
            this.cusnm_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.cusnm_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cusnm_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusnm_txt.Location = new System.Drawing.Point(170, 151);
            this.cusnm_txt.Name = "cusnm_txt";
            this.cusnm_txt.Size = new System.Drawing.Size(423, 32);
            this.cusnm_txt.TabIndex = 18;
            // 
            // age_txt
            // 
            this.age_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.age_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.age_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age_txt.Location = new System.Drawing.Point(170, 234);
            this.age_txt.Name = "age_txt";
            this.age_txt.Size = new System.Drawing.Size(423, 32);
            this.age_txt.TabIndex = 17;
            // 
            // cusid_txt
            // 
            this.cusid_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.cusid_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cusid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusid_txt.Location = new System.Drawing.Point(170, 71);
            this.cusid_txt.Name = "cusid_txt";
            this.cusid_txt.Size = new System.Drawing.Size(423, 32);
            this.cusid_txt.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label8.Location = new System.Drawing.Point(30, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 36);
            this.label8.TabIndex = 15;
            this.label8.Text = "Name :";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label7.Location = new System.Drawing.Point(644, 138);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 36);
            this.label7.TabIndex = 5;
            this.label7.Text = "Email Id :";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label6.Location = new System.Drawing.Point(644, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 36);
            this.label6.TabIndex = 4;
            this.label6.Text = "Date :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label5.Location = new System.Drawing.Point(30, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 36);
            this.label5.TabIndex = 3;
            this.label5.Text = "Age :";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label4.Location = new System.Drawing.Point(644, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 36);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mobile No. :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label2.Location = new System.Drawing.Point(30, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 36);
            this.label2.TabIndex = 0;
            this.label2.Text = "Id :";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.RosyBrown;
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Location = new System.Drawing.Point(303, 545);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1323, 379);
            this.panel3.TabIndex = 7;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeight = 35;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft YaHei", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.LightGray;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 25;
            this.dataGridView1.RowTemplate.DividerHeight = 1;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1323, 379);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.FillWeight = 50F;
            this.Column1.HeaderText = "Id";
            this.Column1.MinimumWidth = 9;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.FillWeight = 150F;
            this.Column2.HeaderText = "Name";
            this.Column2.MinimumWidth = 9;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.FillWeight = 50F;
            this.Column3.HeaderText = "Age";
            this.Column3.MinimumWidth = 9;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.FillWeight = 120F;
            this.Column4.HeaderText = "Mobile Number";
            this.Column4.MinimumWidth = 9;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.FillWeight = 150F;
            this.Column5.HeaderText = "Email";
            this.Column5.MinimumWidth = 9;
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.FillWeight = 50F;
            this.Column6.HeaderText = "Date";
            this.Column6.MinimumWidth = 9;
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1617, 919);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.cuspage_panel);
            this.Controls.Add(this.menu_panel);
            this.Controls.Add(this.header_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.customer_Load);
            this.header_panel.ResumeLayout(false);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).EndInit();
            this.menu_panel.ResumeLayout(false);
            this.cuspage_panel.ResumeLayout(false);
            this.cuspage_panel.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Button maxi_btn;
        private System.Windows.Forms.Button mini_btn;
        private System.Windows.Forms.Panel header_panel;
        private System.Windows.Forms.Button home_btn;
        private System.Windows.Forms.Button measur_btn;
        private System.Windows.Forms.Button cust_btn;
        private System.Windows.Forms.Button bill_btn;
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox menu_pic;
        private System.Windows.Forms.Panel menu_panel;
        private System.Windows.Forms.Panel cuspage_panel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox cusid_txt;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox mno_txt;
        private System.Windows.Forms.TextBox cusnm_txt;
        private System.Windows.Forms.TextBox age_txt;
        private System.Windows.Forms.DateTimePicker cust_date;
        private System.Windows.Forms.Button cusadd_btn;
        private System.Windows.Forms.Button cusupdate_btn;
        private System.Windows.Forms.Button cusdelete_btn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
    }
}