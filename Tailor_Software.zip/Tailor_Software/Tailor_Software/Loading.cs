﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tailor_Software
{
    public partial class Loading : Form
    {
        public Loading()
        {
            InitializeComponent();
        }

        private void progress_timer_Tick(object sender, EventArgs e)
        {
            progress_timer.Enabled = true;
            progressBar1.Increment(3);
            if (progressBar1.Value==100)
            {
                progress_timer.Enabled=false;
                Admin_Login al = new Admin_Login();
                this.Hide();
                al.Show();
            }
        }
    }
}
