﻿namespace Tailor_softwareui
{
    partial class Admin_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gray_penal = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.white_panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.close_btn = new System.Windows.Forms.Button();
            this.user_panel = new System.Windows.Forms.Panel();
            this.lock_panel = new System.Windows.Forms.Panel();
            this.login_btn = new System.Windows.Forms.Button();
            this.usr_txt = new System.Windows.Forms.TextBox();
            this.psw_txt = new System.Windows.Forms.TextBox();
            this.close_eye = new System.Windows.Forms.Button();
            this.eye = new System.Windows.Forms.Button();
            this.lock_pic = new System.Windows.Forms.PictureBox();
            this.user_pic = new System.Windows.Forms.PictureBox();
            this.sessior_pic = new System.Windows.Forms.PictureBox();
            this.gray_penal.SuspendLayout();
            this.white_panel.SuspendLayout();
            this.user_panel.SuspendLayout();
            this.lock_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lock_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sessior_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // gray_penal
            // 
            this.gray_penal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.gray_penal.Controls.Add(this.label5);
            this.gray_penal.Controls.Add(this.label4);
            this.gray_penal.Controls.Add(this.label3);
            this.gray_penal.Controls.Add(this.label2);
            this.gray_penal.Controls.Add(this.label1);
            this.gray_penal.Controls.Add(this.sessior_pic);
            this.gray_penal.Location = new System.Drawing.Point(0, 0);
            this.gray_penal.Name = "gray_penal";
            this.gray_penal.Size = new System.Drawing.Size(372, 726);
            this.gray_penal.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(3, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(354, 44);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tailor Management";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(33, 318);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(284, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome to the";
            // 
            // white_panel
            // 
            this.white_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.white_panel.Controls.Add(this.login_btn);
            this.white_panel.Controls.Add(this.lock_panel);
            this.white_panel.Controls.Add(this.user_panel);
            this.white_panel.Controls.Add(this.close_btn);
            this.white_panel.Controls.Add(this.label6);
            this.white_panel.Location = new System.Drawing.Point(367, 0);
            this.white_panel.Name = "white_panel";
            this.white_panel.Size = new System.Drawing.Size(800, 726);
            this.white_panel.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(107, 453);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 44);
            this.label3.TabIndex = 2;
            this.label3.Text = "System";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS PGothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(233, 576);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Developed by";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS PGothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(189, 611);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "Dhara Gohel";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 21.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label6.Location = new System.Drawing.Point(216, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(339, 68);
            this.label6.TabIndex = 2;
            this.label6.Text = "Admin Login";
            // 
            // close_btn
            // 
            this.close_btn.BackColor = System.Drawing.Color.LightCyan;
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.close_btn.Location = new System.Drawing.Point(737, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(63, 68);
            this.close_btn.TabIndex = 3;
            this.close_btn.Text = "X";
            this.close_btn.UseVisualStyleBackColor = false;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // user_panel
            // 
            this.user_panel.BackColor = System.Drawing.Color.White;
            this.user_panel.Controls.Add(this.usr_txt);
            this.user_panel.Controls.Add(this.user_pic);
            this.user_panel.Location = new System.Drawing.Point(3, 290);
            this.user_panel.Name = "user_panel";
            this.user_panel.Size = new System.Drawing.Size(794, 88);
            this.user_panel.TabIndex = 4;
            // 
            // lock_panel
            // 
            this.lock_panel.BackColor = System.Drawing.Color.White;
            this.lock_panel.Controls.Add(this.eye);
            this.lock_panel.Controls.Add(this.psw_txt);
            this.lock_panel.Controls.Add(this.close_eye);
            this.lock_panel.Controls.Add(this.lock_pic);
            this.lock_panel.Location = new System.Drawing.Point(3, 399);
            this.lock_panel.Name = "lock_panel";
            this.lock_panel.Size = new System.Drawing.Size(794, 88);
            this.lock_panel.TabIndex = 5;
            // 
            // login_btn
            // 
            this.login_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.login_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.login_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.login_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.login_btn.Location = new System.Drawing.Point(64, 559);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(684, 73);
            this.login_btn.TabIndex = 6;
            this.login_btn.Text = "LOGIN";
            this.login_btn.UseVisualStyleBackColor = false;
            // 
            // usr_txt
            // 
            this.usr_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.usr_txt.Font = new System.Drawing.Font("Microsoft YaHei", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usr_txt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.usr_txt.Location = new System.Drawing.Point(136, 21);
            this.usr_txt.Name = "usr_txt";
            this.usr_txt.Size = new System.Drawing.Size(627, 44);
            this.usr_txt.TabIndex = 8;
            // 
            // psw_txt
            // 
            this.psw_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.psw_txt.Font = new System.Drawing.Font("Microsoft YaHei", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.psw_txt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.psw_txt.Location = new System.Drawing.Point(136, 16);
            this.psw_txt.Name = "psw_txt";
            this.psw_txt.PasswordChar = '*';
            this.psw_txt.Size = new System.Drawing.Size(555, 44);
            this.psw_txt.TabIndex = 9;
            // 
            // close_eye
            // 
            this.close_eye.BackgroundImage = global::Tailor_softwareui.Properties.Resources.des_eye;
            this.close_eye.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.close_eye.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_eye.Location = new System.Drawing.Point(730, 3);
            this.close_eye.Name = "close_eye";
            this.close_eye.Size = new System.Drawing.Size(54, 85);
            this.close_eye.TabIndex = 11;
            this.close_eye.UseVisualStyleBackColor = true;
            this.close_eye.Click += new System.EventHandler(this.close_eye_Click);
            // 
            // eye
            // 
            this.eye.BackgroundImage = global::Tailor_softwareui.Properties.Resources.eye;
            this.eye.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eye.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eye.Location = new System.Drawing.Point(730, 4);
            this.eye.Name = "eye";
            this.eye.Size = new System.Drawing.Size(54, 81);
            this.eye.TabIndex = 10;
            this.eye.UseVisualStyleBackColor = true;
            this.eye.Click += new System.EventHandler(this.eye_Click);
            // 
            // lock_pic
            // 
            this.lock_pic.Image = global::Tailor_softwareui.Properties.Resources._lock;
            this.lock_pic.Location = new System.Drawing.Point(23, 16);
            this.lock_pic.Name = "lock_pic";
            this.lock_pic.Size = new System.Drawing.Size(78, 56);
            this.lock_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lock_pic.TabIndex = 8;
            this.lock_pic.TabStop = false;
            // 
            // user_pic
            // 
            this.user_pic.Image = global::Tailor_softwareui.Properties.Resources.user;
            this.user_pic.Location = new System.Drawing.Point(23, 16);
            this.user_pic.Name = "user_pic";
            this.user_pic.Size = new System.Drawing.Size(78, 56);
            this.user_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.user_pic.TabIndex = 7;
            this.user_pic.TabStop = false;
            // 
            // sessior_pic
            // 
            this.sessior_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sessior_pic.Image = global::Tailor_softwareui.Properties.Resources.sessior;
            this.sessior_pic.Location = new System.Drawing.Point(-1, 3);
            this.sessior_pic.Name = "sessior_pic";
            this.sessior_pic.Size = new System.Drawing.Size(362, 240);
            this.sessior_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sessior_pic.TabIndex = 0;
            this.sessior_pic.TabStop = false;
            // 
            // Admin_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 726);
            this.ControlBox = false;
            this.Controls.Add(this.white_panel);
            this.Controls.Add(this.gray_penal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin_Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.gray_penal.ResumeLayout(false);
            this.gray_penal.PerformLayout();
            this.white_panel.ResumeLayout(false);
            this.white_panel.PerformLayout();
            this.user_panel.ResumeLayout(false);
            this.user_panel.PerformLayout();
            this.lock_panel.ResumeLayout(false);
            this.lock_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lock_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sessior_pic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel gray_penal;
        private System.Windows.Forms.Panel white_panel;
        private System.Windows.Forms.PictureBox sessior_pic;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Button login_btn;
        private System.Windows.Forms.Panel lock_panel;
        private System.Windows.Forms.Panel user_panel;
        private System.Windows.Forms.PictureBox user_pic;
        private System.Windows.Forms.PictureBox lock_pic;
        private System.Windows.Forms.TextBox psw_txt;
        private System.Windows.Forms.TextBox usr_txt;
        private System.Windows.Forms.Button close_eye;
        private System.Windows.Forms.Button eye;
    }
}