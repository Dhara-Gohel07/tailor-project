﻿namespace Tailor_softwareui
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.header_panel = new System.Windows.Forms.Panel();
            this.mini_btn = new System.Windows.Forms.Button();
            this.maxi_btn = new System.Windows.Forms.Button();
            this.close_btn = new System.Windows.Forms.Button();
            this.header_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // header_panel
            // 
            this.header_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.header_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.header_panel.Controls.Add(this.mini_btn);
            this.header_panel.Controls.Add(this.maxi_btn);
            this.header_panel.Controls.Add(this.close_btn);
            this.header_panel.Location = new System.Drawing.Point(-14, -12);
            this.header_panel.Name = "header_panel";
            this.header_panel.Size = new System.Drawing.Size(1613, 67);
            this.header_panel.TabIndex = 0;
            // 
            // mini_btn
            // 
            this.mini_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mini_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mini_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mini_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mini_btn.Location = new System.Drawing.Point(1394, 3);
            this.mini_btn.Name = "mini_btn";
            this.mini_btn.Size = new System.Drawing.Size(75, 66);
            this.mini_btn.TabIndex = 2;
            this.mini_btn.Text = "__";
            this.mini_btn.UseVisualStyleBackColor = true;
            this.mini_btn.Click += new System.EventHandler(this.mini_btn_Click);
            // 
            // maxi_btn
            // 
            this.maxi_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maxi_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxi_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxi_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.maxi_btn.Location = new System.Drawing.Point(1466, 0);
            this.maxi_btn.Name = "maxi_btn";
            this.maxi_btn.Size = new System.Drawing.Size(75, 67);
            this.maxi_btn.TabIndex = 2;
            this.maxi_btn.Text = "[ ]";
            this.maxi_btn.UseVisualStyleBackColor = true;
            this.maxi_btn.Click += new System.EventHandler(this.maxi_btn_Click);
            // 
            // close_btn
            // 
            this.close_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.close_btn.Location = new System.Drawing.Point(1538, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 67);
            this.close_btn.TabIndex = 1;
            this.close_btn.Text = "X";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1590, 919);
            this.ControlBox = false;
            this.Controls.Add(this.header_panel);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.header_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel header_panel;
        private System.Windows.Forms.Button mini_btn;
        private System.Windows.Forms.Button maxi_btn;
        private System.Windows.Forms.Button close_btn;
    }
}