﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tailor_softwareui
{
    public partial class Admin_Login : Form
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do You Want To Exit?","Tailor Shop",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void close_eye_Click(object sender, EventArgs e)
        {
           if(psw_txt.PasswordChar=='\0')
            {
                eye.BringToFront();
                psw_txt.PasswordChar= '*';
            }

        }

        private void eye_Click(object sender, EventArgs e)
        {
            if (psw_txt.PasswordChar == '*')
            {
                close_eye.BringToFront();
                psw_txt.PasswordChar = '\0';
             }
        }
        
        private void clear()
        {
            usr_txt.Clear();
            psw_txt.Clear();
            usr_txt.Focus();
        }
        private void login_btn_Click(object sender, EventArgs e)
        {
            if(usr_txt.Text!="" && psw_txt.Text!="")
            {
                string sql = "select * from Admin_login where unm = '" + usr_txt.Text.Trim() + "' and psw = '" + psw_txt.Text.Trim() + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, class_file.con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if(dt.Rows.Count==1 )
                {
                    MessageBox.Show("welcome");
                }
                else
                {
                    MessageBox.Show("Invalid Username Or Password","Tailor Shop",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    clear();
                }
            }
            else
            {
                MessageBox.Show("Enter Missing Data", "Tailor Shop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            }
        }
    }
}
