﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tailor_Software
{
    public partial class Admin_Login : Form
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void eye_btn_Click(object sender, EventArgs e)
        {
            if (psw_txt.PasswordChar == '*')
            {
                deseye_btn.BringToFront();
                psw_txt.PasswordChar = '\0';
            }
        }

       

        private void deseye_btn_Click(object sender, EventArgs e)
        {
            if (psw_txt.PasswordChar == '\0')
            {
                eye_btn.BringToFront();
                psw_txt.PasswordChar = '*';
            }
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do You Want To Exit?", "Tailor_Software", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            Dashboard d=new Dashboard();
            this.Hide();
            d.Show();
        }
    }
}
