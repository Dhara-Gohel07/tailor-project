﻿namespace dashboard
{
    partial class bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close_btn = new System.Windows.Forms.Button();
            this.maxi_btn = new System.Windows.Forms.Button();
            this.mini_btn = new System.Windows.Forms.Button();
            this.header_panel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menu_pic = new System.Windows.Forms.PictureBox();
            this.menu_panel = new System.Windows.Forms.Panel();
            this.bill_btn = new System.Windows.Forms.Button();
            this.cust_btn = new System.Windows.Forms.Button();
            this.measur_btn = new System.Windows.Forms.Button();
            this.home_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.display_grid = new System.Windows.Forms.DataGridView();
            this.bill_detail_panel = new System.Windows.Forms.Panel();
            this.billprint_btn = new System.Windows.Forms.Button();
            this.billadd_btn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.header_panel.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).BeginInit();
            this.menu_panel.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.display_grid)).BeginInit();
            this.bill_detail_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // close_btn
            // 
            this.close_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close_btn.FlatAppearance.BorderSize = 0;
            this.close_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.close_btn.Location = new System.Drawing.Point(1893, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 67);
            this.close_btn.TabIndex = 1;
            this.close_btn.Text = "X";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // maxi_btn
            // 
            this.maxi_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maxi_btn.FlatAppearance.BorderSize = 0;
            this.maxi_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxi_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxi_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.maxi_btn.Location = new System.Drawing.Point(1821, 0);
            this.maxi_btn.Name = "maxi_btn";
            this.maxi_btn.Size = new System.Drawing.Size(75, 67);
            this.maxi_btn.TabIndex = 2;
            this.maxi_btn.Text = "[ ]";
            this.maxi_btn.UseVisualStyleBackColor = true;
            this.maxi_btn.Click += new System.EventHandler(this.maxi_btn_Click);
            // 
            // mini_btn
            // 
            this.mini_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mini_btn.FlatAppearance.BorderSize = 0;
            this.mini_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mini_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mini_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mini_btn.Location = new System.Drawing.Point(1749, 3);
            this.mini_btn.Name = "mini_btn";
            this.mini_btn.Size = new System.Drawing.Size(75, 66);
            this.mini_btn.TabIndex = 2;
            this.mini_btn.Text = "__";
            this.mini_btn.UseVisualStyleBackColor = true;
            this.mini_btn.Click += new System.EventHandler(this.mini_btn_Click);
            // 
            // header_panel
            // 
            this.header_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.header_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.header_panel.Controls.Add(this.mini_btn);
            this.header_panel.Controls.Add(this.maxi_btn);
            this.header_panel.Controls.Add(this.close_btn);
            this.header_panel.Location = new System.Drawing.Point(-14, -12);
            this.header_panel.Name = "header_panel";
            this.header_panel.Size = new System.Drawing.Size(1968, 67);
            this.header_panel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.menu_pic);
            this.panel1.Cursor = System.Windows.Forms.Cursors.No;
            this.panel1.Location = new System.Drawing.Point(19, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(304, 69);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(117, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "MENU";
            // 
            // menu_pic
            // 
            this.menu_pic.Image = global::dashboard.Properties.Resources.menu;
            this.menu_pic.Location = new System.Drawing.Point(0, 0);
            this.menu_pic.Name = "menu_pic";
            this.menu_pic.Size = new System.Drawing.Size(63, 66);
            this.menu_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menu_pic.TabIndex = 4;
            this.menu_pic.TabStop = false;
            // 
            // menu_panel
            // 
            this.menu_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menu_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.menu_panel.Controls.Add(this.panel1);
            this.menu_panel.Controls.Add(this.bill_btn);
            this.menu_panel.Controls.Add(this.cust_btn);
            this.menu_panel.Controls.Add(this.measur_btn);
            this.menu_panel.Controls.Add(this.home_btn);
            this.menu_panel.Location = new System.Drawing.Point(-19, -19);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.Size = new System.Drawing.Size(323, 1068);
            this.menu_panel.TabIndex = 1;
            // 
            // bill_btn
            // 
            this.bill_btn.BackColor = System.Drawing.Color.Teal;
            this.bill_btn.Cursor = System.Windows.Forms.Cursors.Default;
            this.bill_btn.FlatAppearance.BorderSize = 0;
            this.bill_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bill_btn.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Bold);
            this.bill_btn.ForeColor = System.Drawing.Color.White;
            this.bill_btn.Image = global::dashboard.Properties.Resources.bill1;
            this.bill_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bill_btn.Location = new System.Drawing.Point(19, 635);
            this.bill_btn.Name = "bill_btn";
            this.bill_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bill_btn.Size = new System.Drawing.Size(304, 91);
            this.bill_btn.TabIndex = 4;
            this.bill_btn.Text = "     BILL";
            this.bill_btn.UseVisualStyleBackColor = false;
            // 
            // cust_btn
            // 
            this.cust_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cust_btn.FlatAppearance.BorderSize = 0;
            this.cust_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.cust_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cust_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.14286F);
            this.cust_btn.ForeColor = System.Drawing.Color.White;
            this.cust_btn.Image = global::dashboard.Properties.Resources.customer__1_;
            this.cust_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cust_btn.Location = new System.Drawing.Point(19, 364);
            this.cust_btn.Name = "cust_btn";
            this.cust_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.cust_btn.Size = new System.Drawing.Size(304, 91);
            this.cust_btn.TabIndex = 3;
            this.cust_btn.Text = "       CUSTOMERS";
            this.cust_btn.UseVisualStyleBackColor = true;
            this.cust_btn.Click += new System.EventHandler(this.cust_btn_Click_1);
            // 
            // measur_btn
            // 
            this.measur_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.measur_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.measur_btn.FlatAppearance.BorderSize = 0;
            this.measur_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.measur_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.measur_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 9.14286F);
            this.measur_btn.ForeColor = System.Drawing.Color.White;
            this.measur_btn.Image = global::dashboard.Properties.Resources.measurement1;
            this.measur_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.measur_btn.Location = new System.Drawing.Point(19, 496);
            this.measur_btn.Name = "measur_btn";
            this.measur_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.measur_btn.Size = new System.Drawing.Size(304, 91);
            this.measur_btn.TabIndex = 2;
            this.measur_btn.Text = "          MEASUREMENT";
            this.measur_btn.UseVisualStyleBackColor = false;
            this.measur_btn.Click += new System.EventHandler(this.measur_btn_Click);
            // 
            // home_btn
            // 
            this.home_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.home_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.home_btn.FlatAppearance.BorderSize = 0;
            this.home_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.home_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.14286F);
            this.home_btn.ForeColor = System.Drawing.Color.White;
            this.home_btn.Image = global::dashboard.Properties.Resources.home1;
            this.home_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.home_btn.Location = new System.Drawing.Point(19, 233);
            this.home_btn.Name = "home_btn";
            this.home_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.home_btn.Size = new System.Drawing.Size(304, 91);
            this.home_btn.TabIndex = 0;
            this.home_btn.Text = "     HOME";
            this.home_btn.UseVisualStyleBackColor = false;
            this.home_btn.Click += new System.EventHandler(this.home_btn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.display_grid);
            this.panel2.Location = new System.Drawing.Point(416, 162);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 825);
            this.panel2.TabIndex = 6;
            // 
            // display_grid
            // 
            this.display_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.display_grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.display_grid.Location = new System.Drawing.Point(0, 0);
            this.display_grid.Name = "display_grid";
            this.display_grid.RowHeadersWidth = 72;
            this.display_grid.RowTemplate.Height = 31;
            this.display_grid.Size = new System.Drawing.Size(559, 825);
            this.display_grid.TabIndex = 0;
            // 
            // bill_detail_panel
            // 
            this.bill_detail_panel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bill_detail_panel.Controls.Add(this.textBox7);
            this.bill_detail_panel.Controls.Add(this.textBox6);
            this.bill_detail_panel.Controls.Add(this.textBox5);
            this.bill_detail_panel.Controls.Add(this.textBox4);
            this.bill_detail_panel.Controls.Add(this.textBox3);
            this.bill_detail_panel.Controls.Add(this.textBox2);
            this.bill_detail_panel.Controls.Add(this.textBox1);
            this.bill_detail_panel.Controls.Add(this.billprint_btn);
            this.bill_detail_panel.Controls.Add(this.billadd_btn);
            this.bill_detail_panel.Controls.Add(this.label9);
            this.bill_detail_panel.Controls.Add(this.label8);
            this.bill_detail_panel.Controls.Add(this.label7);
            this.bill_detail_panel.Controls.Add(this.label6);
            this.bill_detail_panel.Controls.Add(this.label5);
            this.bill_detail_panel.Controls.Add(this.label4);
            this.bill_detail_panel.Controls.Add(this.label3);
            this.bill_detail_panel.Controls.Add(this.label2);
            this.bill_detail_panel.Location = new System.Drawing.Point(1067, 162);
            this.bill_detail_panel.Name = "bill_detail_panel";
            this.bill_detail_panel.Size = new System.Drawing.Size(760, 825);
            this.bill_detail_panel.TabIndex = 7;
            // 
            // billprint_btn
            // 
            this.billprint_btn.BackColor = System.Drawing.Color.Green;
            this.billprint_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.billprint_btn.FlatAppearance.BorderSize = 2;
            this.billprint_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.billprint_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billprint_btn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.billprint_btn.Location = new System.Drawing.Point(443, 733);
            this.billprint_btn.Name = "billprint_btn";
            this.billprint_btn.Size = new System.Drawing.Size(248, 75);
            this.billprint_btn.TabIndex = 9;
            this.billprint_btn.Text = "PRINT";
            this.billprint_btn.UseVisualStyleBackColor = false;
            // 
            // billadd_btn
            // 
            this.billadd_btn.BackColor = System.Drawing.Color.Brown;
            this.billadd_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.billadd_btn.FlatAppearance.BorderSize = 2;
            this.billadd_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.billadd_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billadd_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.billadd_btn.Location = new System.Drawing.Point(79, 733);
            this.billadd_btn.Name = "billadd_btn";
            this.billadd_btn.Size = new System.Drawing.Size(248, 75);
            this.billadd_btn.TabIndex = 8;
            this.billadd_btn.Text = "ADD";
            this.billadd_btn.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label9.Location = new System.Drawing.Point(21, 650);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 37);
            this.label9.TabIndex = 7;
            this.label9.Text = "Date :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label8.Location = new System.Drawing.Point(21, 553);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(181, 37);
            this.label8.TabIndex = 6;
            this.label8.Text = "Total Price :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label7.Location = new System.Drawing.Point(21, 466);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 37);
            this.label7.TabIndex = 5;
            this.label7.Text = "Discount :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label6.Location = new System.Drawing.Point(21, 382);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 37);
            this.label6.TabIndex = 4;
            this.label6.Text = "Price :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label5.Location = new System.Drawing.Point(21, 299);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 37);
            this.label5.TabIndex = 3;
            this.label5.Text = "Quintite :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label4.Location = new System.Drawing.Point(21, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 37);
            this.label4.TabIndex = 2;
            this.label4.Text = "Suite Type :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label3.Location = new System.Drawing.Point(21, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(262, 37);
            this.label3.TabIndex = 1;
            this.label3.Text = "Customer Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label2.Location = new System.Drawing.Point(21, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(209, 37);
            this.label2.TabIndex = 0;
            this.label2.Text = "Customer ID :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(313, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(415, 34);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(313, 222);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(415, 34);
            this.textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(313, 128);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(415, 34);
            this.textBox3.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(313, 303);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(415, 34);
            this.textBox4.TabIndex = 13;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(313, 386);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(415, 34);
            this.textBox5.TabIndex = 14;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(313, 470);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(415, 34);
            this.textBox6.TabIndex = 15;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(313, 556);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(415, 34);
            this.textBox7.TabIndex = 16;
            // 
            // bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1945, 1041);
            this.ControlBox = false;
            this.Controls.Add(this.bill_detail_panel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.menu_panel);
            this.Controls.Add(this.header_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.bill_Load);
            this.header_panel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).EndInit();
            this.menu_panel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.display_grid)).EndInit();
            this.bill_detail_panel.ResumeLayout(false);
            this.bill_detail_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Button maxi_btn;
        private System.Windows.Forms.Button mini_btn;
        private System.Windows.Forms.Panel header_panel;
        private System.Windows.Forms.Button home_btn;
        private System.Windows.Forms.Button measur_btn;
        private System.Windows.Forms.Button cust_btn;
        private System.Windows.Forms.Button bill_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox menu_pic;
        private System.Windows.Forms.Panel menu_panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView display_grid;
        private System.Windows.Forms.Panel bill_detail_panel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button billadd_btn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button billprint_btn;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}