﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tailor_softwareui
{
    public partial class Loading_Page : Form
    {
        public Loading_Page()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            progressbar.Increment(3);
            if(progressbar.Value==100)
            {
                timer1.Enabled=false;
                Admin_Login al=new Admin_Login();
                al.Show();
                this.Hide();
            }
        }
    }
}
