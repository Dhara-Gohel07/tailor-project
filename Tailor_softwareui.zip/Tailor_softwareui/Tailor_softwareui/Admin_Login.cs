﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tailor_softwareui
{
    public partial class Admin_Login : Form
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do You Want To Exit?","Tailor_Software",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void close_eye_Click(object sender, EventArgs e)
        {
           if(psw_txt.PasswordChar=='\0')
            {
                eye.BringToFront();
                psw_txt.PasswordChar= '*';
            }

        }

        private void eye_Click(object sender, EventArgs e)
        {
            if (psw_txt.PasswordChar == '*')
            {
                close_eye.BringToFront();
                psw_txt.PasswordChar = '\0';
             }
        }
    }
}
