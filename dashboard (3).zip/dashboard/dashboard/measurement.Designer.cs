﻿namespace dashboard
{
    partial class measurement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close_btn = new System.Windows.Forms.Button();
            this.maxi_btn = new System.Windows.Forms.Button();
            this.mini_btn = new System.Windows.Forms.Button();
            this.header_panel = new System.Windows.Forms.Panel();
            this.menu = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menu_pic = new System.Windows.Forms.PictureBox();
            this.menu_panel = new System.Windows.Forms.Panel();
            this.view_measurebtn = new System.Windows.Forms.Button();
            this.bill_btn = new System.Windows.Forms.Button();
            this.cust_btn = new System.Windows.Forms.Button();
            this.measur_btn = new System.Windows.Forms.Button();
            this.home_btn = new System.Windows.Forms.Button();
            this.measurepage_oanel = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.measuredate = new System.Windows.Forms.DateTimePicker();
            this.thigh_txt = new System.Windows.Forms.TextBox();
            this.hem_txt = new System.Windows.Forms.TextBox();
            this.seat_txt = new System.Windows.Forms.TextBox();
            this.rise_txt = new System.Windows.Forms.TextBox();
            this.plength_txt = new System.Windows.Forms.TextBox();
            this.slength_txt = new System.Windows.Forms.TextBox();
            this.sleeve_otxt = new System.Windows.Forms.TextBox();
            this.sleeve_txt = new System.Windows.Forms.TextBox();
            this.neck_txt = new System.Windows.Forms.TextBox();
            this.waist_txt = new System.Windows.Forms.TextBox();
            this.shoulder_txt = new System.Windows.Forms.TextBox();
            this.mview_btn = new System.Windows.Forms.Button();
            this.mdelete_btn = new System.Windows.Forms.Button();
            this.mupdate_btn = new System.Windows.Forms.Button();
            this.madd_btn = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.chest_txt = new System.Windows.Forms.TextBox();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.id_txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.header_panel.SuspendLayout();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).BeginInit();
            this.menu_panel.SuspendLayout();
            this.measurepage_oanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // close_btn
            // 
            this.close_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close_btn.FlatAppearance.BorderSize = 0;
            this.close_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.close_btn.Location = new System.Drawing.Point(1924, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 67);
            this.close_btn.TabIndex = 1;
            this.close_btn.Text = "X";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // maxi_btn
            // 
            this.maxi_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maxi_btn.FlatAppearance.BorderSize = 0;
            this.maxi_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxi_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxi_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.maxi_btn.Location = new System.Drawing.Point(1852, 0);
            this.maxi_btn.Name = "maxi_btn";
            this.maxi_btn.Size = new System.Drawing.Size(75, 67);
            this.maxi_btn.TabIndex = 2;
            this.maxi_btn.Text = "[ ]";
            this.maxi_btn.UseVisualStyleBackColor = true;
            this.maxi_btn.Click += new System.EventHandler(this.maxi_btn_Click);
            // 
            // mini_btn
            // 
            this.mini_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mini_btn.FlatAppearance.BorderSize = 0;
            this.mini_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mini_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mini_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mini_btn.Location = new System.Drawing.Point(1780, 3);
            this.mini_btn.Name = "mini_btn";
            this.mini_btn.Size = new System.Drawing.Size(75, 66);
            this.mini_btn.TabIndex = 2;
            this.mini_btn.Text = "__";
            this.mini_btn.UseVisualStyleBackColor = true;
            this.mini_btn.Click += new System.EventHandler(this.mini_btn_Click);
            // 
            // header_panel
            // 
            this.header_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.header_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.header_panel.Controls.Add(this.mini_btn);
            this.header_panel.Controls.Add(this.maxi_btn);
            this.header_panel.Controls.Add(this.close_btn);
            this.header_panel.Location = new System.Drawing.Point(-14, -12);
            this.header_panel.Name = "header_panel";
            this.header_panel.Size = new System.Drawing.Size(1999, 67);
            this.header_panel.TabIndex = 0;
            // 
            // menu
            // 
            this.menu.Controls.Add(this.label1);
            this.menu.Controls.Add(this.menu_pic);
            this.menu.Cursor = System.Windows.Forms.Cursors.No;
            this.menu.Location = new System.Drawing.Point(19, 80);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(304, 69);
            this.menu.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(117, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "MENU";
            // 
            // menu_pic
            // 
            this.menu_pic.Image = global::dashboard.Properties.Resources.menu;
            this.menu_pic.Location = new System.Drawing.Point(0, 0);
            this.menu_pic.Name = "menu_pic";
            this.menu_pic.Size = new System.Drawing.Size(63, 66);
            this.menu_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menu_pic.TabIndex = 4;
            this.menu_pic.TabStop = false;
            // 
            // menu_panel
            // 
            this.menu_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menu_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.menu_panel.Controls.Add(this.view_measurebtn);
            this.menu_panel.Controls.Add(this.menu);
            this.menu_panel.Controls.Add(this.bill_btn);
            this.menu_panel.Controls.Add(this.cust_btn);
            this.menu_panel.Controls.Add(this.measur_btn);
            this.menu_panel.Controls.Add(this.home_btn);
            this.menu_panel.Location = new System.Drawing.Point(-19, -19);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.Size = new System.Drawing.Size(323, 1028);
            this.menu_panel.TabIndex = 1;
            // 
            // view_measurebtn
            // 
            this.view_measurebtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.view_measurebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.view_measurebtn.FlatAppearance.BorderSize = 0;
            this.view_measurebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.view_measurebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.view_measurebtn.Font = new System.Drawing.Font("Microsoft YaHei Light", 11.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_measurebtn.ForeColor = System.Drawing.Color.Blue;
            this.view_measurebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.view_measurebtn.Location = new System.Drawing.Point(19, 593);
            this.view_measurebtn.Name = "view_measurebtn";
            this.view_measurebtn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.view_measurebtn.Size = new System.Drawing.Size(304, 91);
            this.view_measurebtn.TabIndex = 6;
            this.view_measurebtn.Text = " view";
            this.view_measurebtn.UseVisualStyleBackColor = false;
            this.view_measurebtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // bill_btn
            // 
            this.bill_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.bill_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bill_btn.FlatAppearance.BorderSize = 0;
            this.bill_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bill_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bill_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 11.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_btn.ForeColor = System.Drawing.Color.White;
            this.bill_btn.Image = global::dashboard.Properties.Resources.bill1;
            this.bill_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bill_btn.Location = new System.Drawing.Point(19, 732);
            this.bill_btn.Name = "bill_btn";
            this.bill_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bill_btn.Size = new System.Drawing.Size(304, 91);
            this.bill_btn.TabIndex = 4;
            this.bill_btn.Text = "     BILL";
            this.bill_btn.UseVisualStyleBackColor = false;
            this.bill_btn.Click += new System.EventHandler(this.bill_btn_Click);
            // 
            // cust_btn
            // 
            this.cust_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cust_btn.FlatAppearance.BorderSize = 0;
            this.cust_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.cust_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cust_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.14286F);
            this.cust_btn.ForeColor = System.Drawing.Color.White;
            this.cust_btn.Image = global::dashboard.Properties.Resources.customer__1_;
            this.cust_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cust_btn.Location = new System.Drawing.Point(19, 364);
            this.cust_btn.Name = "cust_btn";
            this.cust_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.cust_btn.Size = new System.Drawing.Size(304, 91);
            this.cust_btn.TabIndex = 3;
            this.cust_btn.Text = "       CUSTOMERS";
            this.cust_btn.UseVisualStyleBackColor = true;
            this.cust_btn.Click += new System.EventHandler(this.cust_btn_Click_1);
            // 
            // measur_btn
            // 
            this.measur_btn.BackColor = System.Drawing.Color.Teal;
            this.measur_btn.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.measur_btn.FlatAppearance.BorderSize = 0;
            this.measur_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.measur_btn.Font = new System.Drawing.Font("Microsoft YaHei", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.measur_btn.ForeColor = System.Drawing.Color.White;
            this.measur_btn.Image = global::dashboard.Properties.Resources.measurement1;
            this.measur_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.measur_btn.Location = new System.Drawing.Point(19, 496);
            this.measur_btn.Name = "measur_btn";
            this.measur_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.measur_btn.Size = new System.Drawing.Size(304, 91);
            this.measur_btn.TabIndex = 2;
            this.measur_btn.Text = "          MEASUREMENT";
            this.measur_btn.UseVisualStyleBackColor = false;
            // 
            // home_btn
            // 
            this.home_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.home_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.home_btn.FlatAppearance.BorderSize = 0;
            this.home_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.home_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.14286F);
            this.home_btn.ForeColor = System.Drawing.Color.White;
            this.home_btn.Image = global::dashboard.Properties.Resources.home1;
            this.home_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.home_btn.Location = new System.Drawing.Point(19, 233);
            this.home_btn.Name = "home_btn";
            this.home_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.home_btn.Size = new System.Drawing.Size(304, 91);
            this.home_btn.TabIndex = 0;
            this.home_btn.Text = "     HOME";
            this.home_btn.UseVisualStyleBackColor = false;
            this.home_btn.Click += new System.EventHandler(this.home_btn_Click_1);
            // 
            // measurepage_oanel
            // 
            this.measurepage_oanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.measurepage_oanel.BackColor = System.Drawing.Color.LightCyan;
            this.measurepage_oanel.Controls.Add(this.label18);
            this.measurepage_oanel.Controls.Add(this.measuredate);
            this.measurepage_oanel.Controls.Add(this.thigh_txt);
            this.measurepage_oanel.Controls.Add(this.hem_txt);
            this.measurepage_oanel.Controls.Add(this.seat_txt);
            this.measurepage_oanel.Controls.Add(this.rise_txt);
            this.measurepage_oanel.Controls.Add(this.plength_txt);
            this.measurepage_oanel.Controls.Add(this.slength_txt);
            this.measurepage_oanel.Controls.Add(this.sleeve_otxt);
            this.measurepage_oanel.Controls.Add(this.sleeve_txt);
            this.measurepage_oanel.Controls.Add(this.neck_txt);
            this.measurepage_oanel.Controls.Add(this.waist_txt);
            this.measurepage_oanel.Controls.Add(this.shoulder_txt);
            this.measurepage_oanel.Controls.Add(this.mview_btn);
            this.measurepage_oanel.Controls.Add(this.mdelete_btn);
            this.measurepage_oanel.Controls.Add(this.mupdate_btn);
            this.measurepage_oanel.Controls.Add(this.madd_btn);
            this.measurepage_oanel.Controls.Add(this.label17);
            this.measurepage_oanel.Controls.Add(this.label16);
            this.measurepage_oanel.Controls.Add(this.label15);
            this.measurepage_oanel.Controls.Add(this.label14);
            this.measurepage_oanel.Controls.Add(this.label13);
            this.measurepage_oanel.Controls.Add(this.chest_txt);
            this.measurepage_oanel.Controls.Add(this.name_txt);
            this.measurepage_oanel.Controls.Add(this.id_txt);
            this.measurepage_oanel.Controls.Add(this.label12);
            this.measurepage_oanel.Controls.Add(this.label11);
            this.measurepage_oanel.Controls.Add(this.label10);
            this.measurepage_oanel.Controls.Add(this.label9);
            this.measurepage_oanel.Controls.Add(this.label8);
            this.measurepage_oanel.Controls.Add(this.label7);
            this.measurepage_oanel.Controls.Add(this.panel3);
            this.measurepage_oanel.Controls.Add(this.label6);
            this.measurepage_oanel.Controls.Add(this.label5);
            this.measurepage_oanel.Controls.Add(this.label4);
            this.measurepage_oanel.Controls.Add(this.label3);
            this.measurepage_oanel.Controls.Add(this.label2);
            this.measurepage_oanel.Location = new System.Drawing.Point(302, 50);
            this.measurepage_oanel.Name = "measurepage_oanel";
            this.measurepage_oanel.Size = new System.Drawing.Size(1683, 956);
            this.measurepage_oanel.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label18.Location = new System.Drawing.Point(840, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(93, 39);
            this.label18.TabIndex = 47;
            this.label18.Text = "Date";
            // 
            // measuredate
            // 
            this.measuredate.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.measuredate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.measuredate.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.measuredate.Location = new System.Drawing.Point(1053, 58);
            this.measuredate.MaxDate = new System.DateTime(2024, 7, 13, 0, 0, 0, 0);
            this.measuredate.Name = "measuredate";
            this.measuredate.Size = new System.Drawing.Size(465, 49);
            this.measuredate.TabIndex = 46;
            this.measuredate.Value = new System.DateTime(2024, 7, 13, 0, 0, 0, 0);
            // 
            // thigh_txt
            // 
            this.thigh_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.thigh_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.thigh_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thigh_txt.Location = new System.Drawing.Point(1044, 538);
            this.thigh_txt.Name = "thigh_txt";
            this.thigh_txt.Size = new System.Drawing.Size(466, 32);
            this.thigh_txt.TabIndex = 45;
            // 
            // hem_txt
            // 
            this.hem_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.hem_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hem_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hem_txt.Location = new System.Drawing.Point(1044, 611);
            this.hem_txt.Name = "hem_txt";
            this.hem_txt.Size = new System.Drawing.Size(466, 32);
            this.hem_txt.TabIndex = 44;
            // 
            // seat_txt
            // 
            this.seat_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.seat_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seat_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seat_txt.Location = new System.Drawing.Point(1044, 456);
            this.seat_txt.Name = "seat_txt";
            this.seat_txt.Size = new System.Drawing.Size(466, 32);
            this.seat_txt.TabIndex = 43;
            // 
            // rise_txt
            // 
            this.rise_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.rise_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rise_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rise_txt.Location = new System.Drawing.Point(1044, 383);
            this.rise_txt.Name = "rise_txt";
            this.rise_txt.Size = new System.Drawing.Size(466, 32);
            this.rise_txt.TabIndex = 42;
            // 
            // plength_txt
            // 
            this.plength_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.plength_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.plength_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plength_txt.Location = new System.Drawing.Point(1234, 313);
            this.plength_txt.Name = "plength_txt";
            this.plength_txt.Size = new System.Drawing.Size(276, 32);
            this.plength_txt.TabIndex = 41;
            // 
            // slength_txt
            // 
            this.slength_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.slength_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.slength_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slength_txt.Location = new System.Drawing.Point(354, 318);
            this.slength_txt.Name = "slength_txt";
            this.slength_txt.Size = new System.Drawing.Size(418, 32);
            this.slength_txt.TabIndex = 40;
            // 
            // sleeve_otxt
            // 
            this.sleeve_otxt.BackColor = System.Drawing.Color.PowderBlue;
            this.sleeve_otxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sleeve_otxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sleeve_otxt.Location = new System.Drawing.Point(306, 760);
            this.sleeve_otxt.Name = "sleeve_otxt";
            this.sleeve_otxt.Size = new System.Drawing.Size(466, 32);
            this.sleeve_otxt.TabIndex = 39;
            // 
            // sleeve_txt
            // 
            this.sleeve_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.sleeve_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sleeve_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sleeve_txt.Location = new System.Drawing.Point(306, 682);
            this.sleeve_txt.Name = "sleeve_txt";
            this.sleeve_txt.Size = new System.Drawing.Size(466, 32);
            this.sleeve_txt.TabIndex = 38;
            // 
            // neck_txt
            // 
            this.neck_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.neck_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.neck_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neck_txt.Location = new System.Drawing.Point(306, 612);
            this.neck_txt.Name = "neck_txt";
            this.neck_txt.Size = new System.Drawing.Size(466, 32);
            this.neck_txt.TabIndex = 37;
            // 
            // waist_txt
            // 
            this.waist_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.waist_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.waist_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waist_txt.Location = new System.Drawing.Point(306, 456);
            this.waist_txt.Name = "waist_txt";
            this.waist_txt.Size = new System.Drawing.Size(466, 32);
            this.waist_txt.TabIndex = 36;
            // 
            // shoulder_txt
            // 
            this.shoulder_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.shoulder_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.shoulder_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoulder_txt.Location = new System.Drawing.Point(306, 538);
            this.shoulder_txt.Name = "shoulder_txt";
            this.shoulder_txt.Size = new System.Drawing.Size(466, 32);
            this.shoulder_txt.TabIndex = 35;
            // 
            // mview_btn
            // 
            this.mview_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.mview_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mview_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mview_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mview_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.mview_btn.Location = new System.Drawing.Point(1305, 857);
            this.mview_btn.Name = "mview_btn";
            this.mview_btn.Size = new System.Drawing.Size(306, 58);
            this.mview_btn.TabIndex = 34;
            this.mview_btn.Text = "VIEW";
            this.mview_btn.UseVisualStyleBackColor = false;
            this.mview_btn.Click += new System.EventHandler(this.view_btn_Click);
            // 
            // mdelete_btn
            // 
            this.mdelete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.mdelete_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mdelete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mdelete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdelete_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.mdelete_btn.Location = new System.Drawing.Point(896, 857);
            this.mdelete_btn.Name = "mdelete_btn";
            this.mdelete_btn.Size = new System.Drawing.Size(308, 58);
            this.mdelete_btn.TabIndex = 33;
            this.mdelete_btn.Text = "DELETE";
            this.mdelete_btn.UseVisualStyleBackColor = false;
            // 
            // mupdate_btn
            // 
            this.mupdate_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.mupdate_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mupdate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mupdate_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mupdate_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.mupdate_btn.Location = new System.Drawing.Point(451, 857);
            this.mupdate_btn.Name = "mupdate_btn";
            this.mupdate_btn.Size = new System.Drawing.Size(321, 58);
            this.mupdate_btn.TabIndex = 32;
            this.mupdate_btn.Text = "UPDATE";
            this.mupdate_btn.UseVisualStyleBackColor = false;
            // 
            // madd_btn
            // 
            this.madd_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.madd_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.madd_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.madd_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.madd_btn.ForeColor = System.Drawing.Color.LightCyan;
            this.madd_btn.Location = new System.Drawing.Point(53, 857);
            this.madd_btn.Name = "madd_btn";
            this.madd_btn.Size = new System.Drawing.Size(329, 58);
            this.madd_btn.TabIndex = 31;
            this.madd_btn.Text = "ADD";
            this.madd_btn.UseVisualStyleBackColor = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label17.Location = new System.Drawing.Point(918, 309);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(296, 36);
            this.label17.TabIndex = 25;
            this.label17.Text = "pnat / lower length :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label16.Location = new System.Drawing.Point(918, 534);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 36);
            this.label16.TabIndex = 24;
            this.label16.Text = "thigh :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label15.Location = new System.Drawing.Point(918, 379);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 36);
            this.label15.TabIndex = 23;
            this.label15.Text = "rise :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label14.Location = new System.Drawing.Point(918, 452);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 36);
            this.label14.TabIndex = 22;
            this.label14.Text = "seat :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label13.Location = new System.Drawing.Point(918, 608);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 36);
            this.label13.TabIndex = 21;
            this.label13.Text = "hem :";
            // 
            // chest_txt
            // 
            this.chest_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.chest_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chest_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chest_txt.Location = new System.Drawing.Point(306, 382);
            this.chest_txt.Name = "chest_txt";
            this.chest_txt.Size = new System.Drawing.Size(466, 32);
            this.chest_txt.TabIndex = 14;
            // 
            // name_txt
            // 
            this.name_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.name_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.name_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_txt.Location = new System.Drawing.Point(233, 135);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(485, 32);
            this.name_txt.TabIndex = 13;
            // 
            // id_txt
            // 
            this.id_txt.BackColor = System.Drawing.Color.PowderBlue;
            this.id_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.id_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_txt.Location = new System.Drawing.Point(233, 43);
            this.id_txt.Name = "id_txt";
            this.id_txt.Size = new System.Drawing.Size(477, 32);
            this.id_txt.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label12.Location = new System.Drawing.Point(67, 313);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(252, 32);
            this.label12.TabIndex = 11;
            this.label12.Text = "shirt/kurta length:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label11.Location = new System.Drawing.Point(67, 756);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(204, 36);
            this.label11.TabIndex = 10;
            this.label11.Text = "sleeve open :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label10.Location = new System.Drawing.Point(67, 608);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 36);
            this.label10.TabIndex = 9;
            this.label10.Text = "neck :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label9.Location = new System.Drawing.Point(67, 679);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 36);
            this.label9.TabIndex = 8;
            this.label9.Text = "sleeve :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label8.Location = new System.Drawing.Point(67, 453);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 36);
            this.label8.TabIndex = 7;
            this.label8.Text = "waist :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label7.Location = new System.Drawing.Point(67, 534);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 36);
            this.label7.TabIndex = 6;
            this.label7.Text = "shoulder :";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.panel3.Location = new System.Drawing.Point(834, 215);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 592);
            this.panel3.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label6.Location = new System.Drawing.Point(889, 216);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(0, 0, 150, 0);
            this.label6.Size = new System.Drawing.Size(597, 39);
            this.label6.TabIndex = 4;
            this.label6.Text = "Lower / Pant Measurement";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label5.Location = new System.Drawing.Point(88, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 39);
            this.label5.TabIndex = 3;
            this.label5.Text = "Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label4.Location = new System.Drawing.Point(46, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(430, 39);
            this.label4.TabIndex = 2;
            this.label4.Text = "Shirt / kurta Measurement";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label3.Location = new System.Drawing.Point(67, 379);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 36);
            this.label3.TabIndex = 1;
            this.label3.Text = "chest :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.label2.Location = new System.Drawing.Point(88, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 39);
            this.label2.TabIndex = 0;
            this.label2.Text = "Id :";
            // 
            // measurement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1976, 1001);
            this.ControlBox = false;
            this.Controls.Add(this.measurepage_oanel);
            this.Controls.Add(this.menu_panel);
            this.Controls.Add(this.header_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "measurement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.measurement_Load);
            this.header_panel.ResumeLayout(false);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).EndInit();
            this.menu_panel.ResumeLayout(false);
            this.measurepage_oanel.ResumeLayout(false);
            this.measurepage_oanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Button maxi_btn;
        private System.Windows.Forms.Button mini_btn;
        private System.Windows.Forms.Panel header_panel;
        private System.Windows.Forms.Button home_btn;
        private System.Windows.Forms.Button measur_btn;
        private System.Windows.Forms.Button cust_btn;
        private System.Windows.Forms.Button bill_btn;
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox menu_pic;
        private System.Windows.Forms.Panel menu_panel;
        private System.Windows.Forms.Button view_measurebtn;
        private System.Windows.Forms.Panel measurepage_oanel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox id_txt;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox chest_txt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button mdelete_btn;
        private System.Windows.Forms.Button mupdate_btn;
        private System.Windows.Forms.Button madd_btn;
        private System.Windows.Forms.Button mview_btn;
        private System.Windows.Forms.TextBox slength_txt;
        private System.Windows.Forms.TextBox sleeve_otxt;
        private System.Windows.Forms.TextBox sleeve_txt;
        private System.Windows.Forms.TextBox neck_txt;
        private System.Windows.Forms.TextBox waist_txt;
        private System.Windows.Forms.TextBox shoulder_txt;
        private System.Windows.Forms.TextBox thigh_txt;
        private System.Windows.Forms.TextBox hem_txt;
        private System.Windows.Forms.TextBox seat_txt;
        private System.Windows.Forms.TextBox rise_txt;
        private System.Windows.Forms.TextBox plength_txt;
        private System.Windows.Forms.DateTimePicker measuredate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label5;
    }
}