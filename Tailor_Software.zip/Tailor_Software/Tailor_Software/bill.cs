﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tailor_Software
{
    public partial class bill : Form
    {
        public bill()
        {
            InitializeComponent();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(MessageBox.Show("Do You Want to Exit?", "dashboard", MessageBoxButtons.YesNo));
            if (a == 6)
            {
                Application.Exit();
            }
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            resize();
        }
        private void resize()
        {
            close_btn.Location = new Point(this.Width - close_btn.Width, 0);
           maxi_btn.Location = new Point(this.Width - maxi_btn.Width - close_btn.Width, 0);
            mini_btn.Location = new Point(this.Width - mini_btn.Width - maxi_btn.Width - close_btn.Width, 0);
        }

        private void maxi_btn_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
                resize();
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
                resize();
            }
        }

        private void mini_btn_Click(object sender, EventArgs e)
        {
            
                this.WindowState = FormWindowState.Minimized;
                
        }

        private void measur_btn_Click(object sender, EventArgs e)
        {
            measurement m=new measurement();
            this.Hide();
            m.Show();
        }

        private void cust_btn_Click(object sender, EventArgs e)
        {
            customer c = new customer();
            this.Hide();
            c.Show();
        }

        private void home_btn_Click(object sender, EventArgs e)
        {
            home h=new home();
            this.Hide();
            h.Show();
        }

    }
}
