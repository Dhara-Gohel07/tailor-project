﻿namespace dashboard
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close_btn = new System.Windows.Forms.Button();
            this.maxi_btn = new System.Windows.Forms.Button();
            this.mini_btn = new System.Windows.Forms.Button();
            this.header_panel = new System.Windows.Forms.Panel();
            this.menu = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menu_pic = new System.Windows.Forms.PictureBox();
            this.menu_panel = new System.Windows.Forms.Panel();
            this.bill_btn = new System.Windows.Forms.Button();
            this.cust_btn = new System.Windows.Forms.Button();
            this.measur_btn = new System.Windows.Forms.Button();
            this.home_btn = new System.Windows.Forms.Button();
            this.dashboard_pic = new System.Windows.Forms.PictureBox();
            this.header_panel.SuspendLayout();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).BeginInit();
            this.menu_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dashboard_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // close_btn
            // 
            this.close_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close_btn.FlatAppearance.BorderSize = 0;
            this.close_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.close_btn.Location = new System.Drawing.Point(1538, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 67);
            this.close_btn.TabIndex = 1;
            this.close_btn.Text = "X";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // maxi_btn
            // 
            this.maxi_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maxi_btn.FlatAppearance.BorderSize = 0;
            this.maxi_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxi_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxi_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.maxi_btn.Location = new System.Drawing.Point(1466, 0);
            this.maxi_btn.Name = "maxi_btn";
            this.maxi_btn.Size = new System.Drawing.Size(75, 67);
            this.maxi_btn.TabIndex = 2;
            this.maxi_btn.Text = "[ ]";
            this.maxi_btn.UseVisualStyleBackColor = true;
            this.maxi_btn.Click += new System.EventHandler(this.maxi_btn_Click);
            // 
            // mini_btn
            // 
            this.mini_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mini_btn.FlatAppearance.BorderSize = 0;
            this.mini_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mini_btn.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mini_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mini_btn.Location = new System.Drawing.Point(1394, 3);
            this.mini_btn.Name = "mini_btn";
            this.mini_btn.Size = new System.Drawing.Size(75, 66);
            this.mini_btn.TabIndex = 2;
            this.mini_btn.Text = "__";
            this.mini_btn.UseVisualStyleBackColor = true;
            this.mini_btn.Click += new System.EventHandler(this.mini_btn_Click);
            // 
            // header_panel
            // 
            this.header_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.header_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.header_panel.Controls.Add(this.mini_btn);
            this.header_panel.Controls.Add(this.maxi_btn);
            this.header_panel.Controls.Add(this.close_btn);
            this.header_panel.Location = new System.Drawing.Point(-14, -12);
            this.header_panel.Name = "header_panel";
            this.header_panel.Size = new System.Drawing.Size(1613, 67);
            this.header_panel.TabIndex = 0;
            // 
            // menu
            // 
            this.menu.Controls.Add(this.label1);
            this.menu.Controls.Add(this.menu_pic);
            this.menu.Cursor = System.Windows.Forms.Cursors.No;
            this.menu.Location = new System.Drawing.Point(19, 80);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(304, 69);
            this.menu.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(117, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "MENU";
            // 
            // menu_pic
            // 
            this.menu_pic.Image = global::dashboard.Properties.Resources.menu;
            this.menu_pic.Location = new System.Drawing.Point(0, 0);
            this.menu_pic.Name = "menu_pic";
            this.menu_pic.Size = new System.Drawing.Size(63, 66);
            this.menu_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menu_pic.TabIndex = 4;
            this.menu_pic.TabStop = false;
            // 
            // menu_panel
            // 
            this.menu_panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menu_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.menu_panel.Controls.Add(this.menu);
            this.menu_panel.Controls.Add(this.bill_btn);
            this.menu_panel.Controls.Add(this.cust_btn);
            this.menu_panel.Controls.Add(this.measur_btn);
            this.menu_panel.Controls.Add(this.home_btn);
            this.menu_panel.Location = new System.Drawing.Point(-19, -19);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.Size = new System.Drawing.Size(323, 946);
            this.menu_panel.TabIndex = 1;
            // 
            // bill_btn
            // 
            this.bill_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.bill_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bill_btn.FlatAppearance.BorderSize = 0;
            this.bill_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bill_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bill_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_btn.ForeColor = System.Drawing.Color.White;
            this.bill_btn.Image = global::dashboard.Properties.Resources.bill1;
            this.bill_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bill_btn.Location = new System.Drawing.Point(19, 635);
            this.bill_btn.Name = "bill_btn";
            this.bill_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bill_btn.Size = new System.Drawing.Size(304, 91);
            this.bill_btn.TabIndex = 4;
            this.bill_btn.Text = "     BILL";
            this.bill_btn.UseVisualStyleBackColor = false;
            this.bill_btn.Click += new System.EventHandler(this.bill_btn_Click);
            // 
            // cust_btn
            // 
            this.cust_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cust_btn.FlatAppearance.BorderSize = 0;
            this.cust_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.cust_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cust_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.14286F);
            this.cust_btn.ForeColor = System.Drawing.Color.White;
            this.cust_btn.Image = global::dashboard.Properties.Resources.customer__1_;
            this.cust_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cust_btn.Location = new System.Drawing.Point(19, 364);
            this.cust_btn.Name = "cust_btn";
            this.cust_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.cust_btn.Size = new System.Drawing.Size(304, 91);
            this.cust_btn.TabIndex = 3;
            this.cust_btn.Text = "       CUSTOMERS";
            this.cust_btn.UseVisualStyleBackColor = true;
            this.cust_btn.Click += new System.EventHandler(this.cust_btn_Click_1);
            // 
            // measur_btn
            // 
            this.measur_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(91)))), ((int)(((byte)(92)))));
            this.measur_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.measur_btn.FlatAppearance.BorderSize = 0;
            this.measur_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.measur_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.measur_btn.Font = new System.Drawing.Font("Microsoft YaHei Light", 9.14286F);
            this.measur_btn.ForeColor = System.Drawing.Color.White;
            this.measur_btn.Image = global::dashboard.Properties.Resources.measurement1;
            this.measur_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.measur_btn.Location = new System.Drawing.Point(19, 496);
            this.measur_btn.Name = "measur_btn";
            this.measur_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.measur_btn.Size = new System.Drawing.Size(304, 91);
            this.measur_btn.TabIndex = 2;
            this.measur_btn.Text = "          MEASUREMENT";
            this.measur_btn.UseVisualStyleBackColor = false;
            this.measur_btn.Click += new System.EventHandler(this.measur_btn_Click_1);
            // 
            // home_btn
            // 
            this.home_btn.BackColor = System.Drawing.Color.Teal;
            this.home_btn.Cursor = System.Windows.Forms.Cursors.Default;
            this.home_btn.FlatAppearance.BorderSize = 0;
            this.home_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home_btn.Font = new System.Drawing.Font("Microsoft YaHei", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home_btn.ForeColor = System.Drawing.Color.White;
            this.home_btn.Image = global::dashboard.Properties.Resources.home1;
            this.home_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.home_btn.Location = new System.Drawing.Point(19, 233);
            this.home_btn.Name = "home_btn";
            this.home_btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.home_btn.Size = new System.Drawing.Size(304, 91);
            this.home_btn.TabIndex = 0;
            this.home_btn.Text = "     HOME";
            this.home_btn.UseVisualStyleBackColor = false;
            // 
            // dashboard_pic
            // 
            this.dashboard_pic.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dashboard_pic.Image = global::dashboard.Properties.Resources.machine_gif;
            this.dashboard_pic.Location = new System.Drawing.Point(300, 48);
            this.dashboard_pic.Name = "dashboard_pic";
            this.dashboard_pic.Size = new System.Drawing.Size(1296, 1063);
            this.dashboard_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dashboard_pic.TabIndex = 2;
            this.dashboard_pic.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1590, 919);
            this.ControlBox = false;
            this.Controls.Add(this.dashboard_pic);
            this.Controls.Add(this.menu_panel);
            this.Controls.Add(this.header_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Home_Load);
            this.header_panel.ResumeLayout(false);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu_pic)).EndInit();
            this.menu_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dashboard_pic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Button maxi_btn;
        private System.Windows.Forms.Button mini_btn;
        private System.Windows.Forms.Panel header_panel;
        private System.Windows.Forms.Button home_btn;
        private System.Windows.Forms.Button measur_btn;
        private System.Windows.Forms.Button cust_btn;
        private System.Windows.Forms.Button bill_btn;
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox menu_pic;
        private System.Windows.Forms.Panel menu_panel;
        private System.Windows.Forms.PictureBox dashboard_pic;
    }
}